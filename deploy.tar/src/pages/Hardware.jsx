import { hardware } from '../data/mockData';
import { Package, Smartphone, Router } from 'lucide-react';

const Hardware = () => {
    return (
        <div className="space-y-3 px-4 md:px-8 pt-3 md:pt-4 pb-24 w-full text-foreground">
            {/* Header - Dashboard Pattern */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-4xl md:text-5xl font-black tracking-tight text-gradient">
                        Hardware
                    </h1>
                    <p className="text-sm text-muted-foreground font-medium mt-0.5">
                        {hardware.length} Geräte im Inventar
                    </p>
                </div>
            </div>

            <div className="grid-list">
                {hardware.map(item => (
                    <div key={item.id} className="card animate-fade-in">
                        <div style={{ height: '140px', background: 'var(--bg-hover)', borderRadius: '8px', display: 'flex', alignItems: 'center', justifyContent: 'center', marginBottom: '16px', color: 'var(--text-muted)' }}>
                            {item.category === 'Router' ? <Router size={48} /> : item.category === 'Smartphone' ? <Smartphone size={48} /> : <Package size={48} />}
                        </div>

                        <div className="customer-name" style={{ fontSize: '18px' }}>{item.name}</div>
                        <div className="customer-contact" style={{ marginBottom: '16px' }}>{item.category}</div>

                        <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
                            <div style={{ fontSize: '20px', fontWeight: '700' }}>€ {item.price.toFixed(2)}</div>
                            <div className={`badge ${item.stock > 5 ? 'badge-success' : 'badge-danger'}`}>
                                {item.stock} Stück
                            </div>
                        </div>
                    </div>
                ))}
            </div>
        </div>
    );
};

export default Hardware;
