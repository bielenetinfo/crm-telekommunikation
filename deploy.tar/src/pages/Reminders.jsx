import { useState } from "react";
import { base44 } from "@/api/base44Client";
import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Search, Bell, Check, Calendar, Mail, MessageSquare } from "lucide-react";
import { format } from "date-fns";
import { de } from "date-fns/locale";
import { cn } from "@/lib/utils";

const statusColors = {
  offen: "bg-amber-500/15 text-amber-400 border-amber-500/30",
  versendet: "bg-blue-500/15 text-blue-400 border-blue-500/30",
  erledigt: "bg-emerald-500/15 text-emerald-400 border-emerald-500/30",
  ignoriert: "bg-slate-500/15 text-slate-400 border-slate-500/30"
};

const typeColors = {
  "30d": "bg-blue-500/15 text-blue-400",
  "14d": "bg-cyan-500/15 text-cyan-400",
  "7d": "bg-amber-500/15 text-amber-400",
  "1d": "bg-rose-500/15 text-rose-400",
  "expired": "bg-rose-600/15 text-rose-500"
};

export default function Reminders() {
  const [search, setSearch] = useState("");
  const [statusFilter, setStatusFilter] = useState("offen");
  const queryClient = useQueryClient();

  const { data: reminders = [], isLoading } = useQuery({
    queryKey: ['reminders'],
    queryFn: () => base44.entities.Reminder.list('-created_date')
  });

  const updateMutation = useMutation({
    mutationFn: ({ id, data }) => base44.entities.Reminder.update(id, data),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['reminders'] });
    }
  });

  const handleSend = (reminder, via) => {
    updateMutation.mutate({
      id: reminder.id,
      data: {
        status: 'versendet',
        sent_date: format(new Date(), 'yyyy-MM-dd'),
        sent_via: via
      }
    });
  };

  const handleStatusChange = (reminder, status) => {
    updateMutation.mutate({
      id: reminder.id,
      data: { status }
    });
  };

  const filteredReminders = reminders.filter(r => {
    const searchLower = search.toLowerCase();
    const matchesSearch =
      r.customer_name?.toLowerCase().includes(searchLower) ||
      r.contract_number?.toLowerCase().includes(searchLower) ||
      r.provider_name?.toLowerCase().includes(searchLower);

    const matchesStatus = statusFilter === "all" || r.status === statusFilter;

    return matchesSearch && matchesStatus;
  });

  return (
    <div className="space-y-3 px-4 md:px-8 pt-3 md:pt-4 pb-24 w-full text-foreground">
      {/* Header - Dashboard Pattern */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-4xl md:text-5xl font-black tracking-tight text-gradient">
            Erinnerungen
          </h1>
          <p className="text-sm text-muted-foreground font-medium mt-0.5">
            {reminders.length} Erinnerungen
          </p>
        </div>
      </div>

      {/* Filters */}
      <div className="flex flex-col sm:flex-row gap-3">
        <div className="relative flex-1 max-w-md">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-[#6B7280]" />
          <Input
            placeholder="Suchen nach Kunde, Vertragsnummer..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10 h-11 bg-[#1F2228] border-[#2D3139] text-[#EAECEF]"
          />
        </div>
        <Tabs value={statusFilter} onValueChange={setStatusFilter}>
          <TabsList className="bg-[#1F2228]">
            <TabsTrigger value="offen" className="data-[state=active]:bg-[#FFD24D] data-[state=active]:text-[#0F1115]">Offen</TabsTrigger>
            <TabsTrigger value="versendet" className="data-[state=active]:bg-[#FFD24D] data-[state=active]:text-[#0F1115]">Versendet</TabsTrigger>
            <TabsTrigger value="erledigt" className="data-[state=active]:bg-[#FFD24D] data-[state=active]:text-[#0F1115]">Erledigt</TabsTrigger>
            <TabsTrigger value="all" className="data-[state=active]:bg-[#FFD24D] data-[state=active]:text-[#0F1115]">Alle</TabsTrigger>
          </TabsList>
        </Tabs>
      </div>

      {/* Reminders List */}
      {isLoading ? (
        <div className="space-y-4">
          {[1, 2, 3].map(i => (
            <Card key={i} className="p-6 bg-[#181B21] border-[#2D3139]">
              <div className="h-4 bg-[#1F2228] rounded w-1/3 mb-2" />
              <div className="h-3 bg-[#1F2228] rounded w-1/2" />
            </Card>
          ))}
        </div>
      ) : filteredReminders.length === 0 ? (
        <Card className="p-12 text-center bg-[#181B21] border-[#2D3139]">
          <Bell className="h-12 w-12 mx-auto text-[#6B7280] mb-4" />
          <h3 className="text-lg font-semibold text-[#EAECEF] mb-1">Keine Erinnerungen gefunden</h3>
          <p className="text-[#6B7280]">Erinnerungen werden automatisch für ablaufende Verträge erstellt.</p>
        </Card>
      ) : (
        <div className="space-y-3">
          {filteredReminders.map(reminder => {
            const daysUntil = reminder.days_until_deadline || 0;
            return (
              <Card
                key={reminder.id}
                className="p-5 bg-[#181B21] border-[#2D3139] hover:border-[#FFD24D]/30 transition-all duration-200"
              >
                <div className="flex flex-col lg:flex-row lg:items-center gap-3">
                  {/* Icon & Info */}
                  <div className="flex items-start gap-4 flex-1 min-w-0">
                    <div className={cn(
                      "h-12 w-12 rounded-xl flex items-center justify-center flex-shrink-0",
                      daysUntil <= 7 ? "bg-rose-500/20" :
                        daysUntil <= 14 ? "bg-amber-500/20" :
                          "bg-blue-500/20"
                    )}>
                      <Bell className={cn(
                        "h-6 w-6",
                        daysUntil <= 7 ? "text-rose-400" :
                          daysUntil <= 14 ? "text-amber-400" :
                            "text-blue-400"
                      )} />
                    </div>
                    <div className="flex-1 min-w-0">
                      <div className="flex items-center gap-2 flex-wrap mb-1">
                        <h3 className="font-semibold text-[#EAECEF]">{reminder.customer_name}</h3>
                        <Badge className={cn("text-xs border", statusColors[reminder.status])}>
                          {reminder.status}
                        </Badge>
                        <Badge className={cn("text-xs", typeColors[reminder.reminder_type])}>
                          {reminder.reminder_type}
                        </Badge>
                        {daysUntil >= 0 && (
                          <Badge className={cn(
                            "text-xs",
                            daysUntil <= 7 ? "bg-rose-500/15 text-rose-400" :
                              daysUntil <= 14 ? "bg-amber-500/15 text-amber-400" :
                                "bg-blue-500/15 text-blue-400"
                          )}>
                            {daysUntil} Tage
                          </Badge>
                        )}
                      </div>
                      <div className="flex flex-wrap items-center gap-x-4 gap-y-1 text-sm text-[#9CA3AF]">
                        <span className="font-medium text-[#FFD24D]">{reminder.provider_name}</span>
                        {reminder.contract_number && (
                          <>
                            <span>•</span>
                            <span>Nr. {reminder.contract_number}</span>
                          </>
                        )}
                        {reminder.cancellation_deadline && (
                          <>
                            <span>•</span>
                            <div className="flex items-center gap-1">
                              <Calendar className="h-3 w-3" />
                              <span>Frist: {format(new Date(reminder.cancellation_deadline), 'dd.MM.yyyy', { locale: de })}</span>
                            </div>
                          </>
                        )}
                      </div>
                      {reminder.sent_date && (
                        <p className="text-xs text-[#6B7280] mt-1">
                          Versendet: {format(new Date(reminder.sent_date), 'dd.MM.yyyy', { locale: de })} via {reminder.sent_via}
                        </p>
                      )}
                    </div>
                  </div>

                  {/* Actions */}
                  {reminder.status === 'offen' && (
                    <div className="flex items-center gap-2">
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSend(reminder, 'email')}
                        className="border-[#2D3139] text-[#9CA3AF] hover:border-[#FFD24D]/30 hover:text-[#FFD24D]"
                      >
                        <Mail className="h-4 w-4 mr-1" />
                        E-Mail
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleSend(reminder, 'whatsapp')}
                        className="border-[#2D3139] text-[#9CA3AF] hover:border-[#FFD24D]/30 hover:text-[#FFD24D]"
                      >
                        <MessageSquare className="h-4 w-4 mr-1" />
                        WhatsApp
                      </Button>
                      <Button
                        size="sm"
                        variant="outline"
                        onClick={() => handleStatusChange(reminder, 'erledigt')}
                        className="border-[#2D3139] text-[#9CA3AF] hover:border-emerald-500/30 hover:text-emerald-400"
                      >
                        <Check className="h-4 w-4" />
                      </Button>
                    </div>
                  )}

                  {reminder.status === 'versendet' && (
                    <Button
                      size="sm"
                      onClick={() => handleStatusChange(reminder, 'erledigt')}
                      className="bg-emerald-500/20 text-emerald-400 hover:bg-emerald-500/30"
                    >
                      <Check className="h-4 w-4 mr-1" />
                      Als erledigt markieren
                    </Button>
                  )}
                </div>
              </Card>
            );
          })}
        </div>
      )}
    </div>
  );
}