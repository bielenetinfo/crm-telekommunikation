import { useNavigate } from 'react-router-dom';
import { useAuth } from '@/lib/AuthContext';
import TwoFactorSetup from '@/components/TwoFactorSetup';
import { Button } from '@/components/ui/button';
import { LogOut, User, Shield } from 'lucide-react';
import { Card, CardHeader, CardTitle, CardContent, CardDescription } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { cn } from '@/lib/utils';

const Settings = () => {
    const { user, logout } = useAuth();
    const navigate = useNavigate();

    const handleLogout = () => {
        logout();
        navigate('/login');
    };

    return (
        <div className="space-y-3 px-4 md:px-8 pt-3 md:pt-4 pb-24 w-full text-foreground">
            {/* Header - Dashboard Pattern */}
            <div className="flex items-center justify-between">
                <div>
                    <h1 className="text-4xl md:text-5xl font-black tracking-tight text-gradient">
                        Einstellungen
                    </h1>
                    <p className="text-sm text-muted-foreground font-medium mt-0.5">
                        Profil und Sicherheit
                    </p>
                </div>
            </div>

            <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-3 gap-6 items-start">
                {/* Profile Card */}
                <Card className="glass-card card-premium overflow-hidden border-transparent hover:border-primary/20 group">
                    <div className="h-1.5 bg-gradient-to-r from-primary to-orange-400"></div>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-xl font-black tracking-tight">
                            <div className="p-2 rounded-xl bg-primary/10 text-primary">
                                <User className="h-5 w-5" />
                            </div>
                            Mein Profil
                        </CardTitle>
                        <CardDescription className="text-muted-foreground font-medium text-xs">
                            Persönliche Daten und Kontoinformationen.
                        </CardDescription>
                    </CardHeader>
                    <CardContent className="space-y-6">
                        <div className="flex items-center gap-5 p-4 rounded-2xl bg-secondary/30 border border-border/50">
                            <div className="h-16 w-16 rounded-2xl bg-gradient-to-br from-primary to-orange-400 flex items-center justify-center text-[#0F1115] font-black text-2xl shadow-lg shadow-primary/20">
                                {user?.name?.charAt(0) || user?.email?.charAt(0).toUpperCase()}
                            </div>
                            <div>
                                <h3 className="text-lg font-black text-foreground">{user?.name}</h3>
                                <p className="text-sm font-medium text-muted-foreground">{user?.email}</p>
                                <Badge className={cn(
                                    "mt-2 text-[9px] uppercase tracking-widest font-black border-none px-2 py-0.5",
                                    user?.role === 'admin' ? "bg-primary/20 text-primary" : "bg-blue-500/20 text-blue-500"
                                )}>
                                    {user?.role || 'User'}
                                </Badge>
                            </div>
                        </div>

                        <Button
                            variant="destructive"
                            onClick={handleLogout}
                            className="w-full h-12 rounded-xl font-bold uppercase tracking-wider text-xs shadow-lg shadow-rose-500/10 hover:bg-rose-600 transition-all hover:scale-[1.02]"
                        >
                            <LogOut className="h-4 w-4 mr-2" /> Abmelden
                        </Button>
                    </CardContent>
                </Card>

                {/* Security Card */}
                <Card className="glass-card card-premium overflow-hidden border-transparent hover:border-blue-500/20 group">
                    <div className="h-1.5 bg-gradient-to-r from-blue-500 to-cyan-400"></div>
                    <CardHeader>
                        <CardTitle className="flex items-center gap-3 text-xl font-black tracking-tight">
                            <div className="p-2 rounded-xl bg-blue-500/10 text-blue-500">
                                <Shield className="h-5 w-5" />
                            </div>
                            Sicherheit
                        </CardTitle>
                        <CardDescription className="text-muted-foreground font-medium text-xs">
                            Zweifaktor-Authentifizierung (2FA) und Zugriffsschutz.
                        </CardDescription>
                    </CardHeader>
                    <CardContent>
                        <TwoFactorSetup />
                    </CardContent>
                </Card>
            </div>
        </div>
    );
};

export default Settings;
