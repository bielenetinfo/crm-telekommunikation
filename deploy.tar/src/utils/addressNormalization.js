/**
 * Normalizes an address into a comparable string format.
 * simple string concatenation for now.
 */
export const normalizeAddress = (street, number, zip, city) => {
    const s = street ? street.trim().toLowerCase() : "";
    const n = number ? number.trim().toLowerCase() : "";
    const z = zip ? zip.trim() : "";
    const c = city ? city.trim().toLowerCase() : "";
    return `${s} ${n}, ${z} ${c}`;
};

/**
 * Checks if two normalized address strings match.
 */
export const addressesMatch = (addr1, addr2) => {
    if (!addr1 || !addr2) return false;
    return addr1 === addr2;
};
